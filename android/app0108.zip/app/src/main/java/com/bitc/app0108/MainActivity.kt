package com.bitc.app0108

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bitc.app0108.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnRecyclerView.setOnClickListener{
            val intent = Intent(this, RecyclerViewActivity::class.java)
            startActivity(intent)
        }

        binding.btnKaKaoChat.setOnClickListener{
        val intent = Intent(this, RecyclerViewActivity::class.java)
        startActivity(intent)
        }


//        문제 1) 카카오톡 채팅방 리스트를 따라하는 리사이클러 뷰를 작성하세요
//        # 채팅방 목록은 5개
//        # 리스트에 표시될 데이터는 이름,프로필사진,채팅내용,시간(해당 데이터는 데이터 클래스 타입의 객체로 전달)
//        # 액티비티 명 : ChatActivity.kt , activity_chat.xml
//        # 리사이클뷰 항목 xml 명 : item_chat.xml
//        # ViewHolder 명 : ChatViewHolder
//        # Adapter 명 : ChatAdapter
    }
}