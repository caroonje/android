package com.bitc.app0108

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bitc.app0108.databinding.ItemMainBinding

// xml 파일을 파싱한 ViewHolder 를 여러개 가지는 Adapter 클래스
// 매개변수로 리사이클러 뷰에 표시할 데이터를 받아옴
class MyAdapter(private val items: MutableList<String>): RecyclerView.Adapter<RecyclerView.ViewHolder>() {
//    ViewHolder 의 수를 반환
    override fun getItemCount(): Int {
        return items.size
    }
//    ViewHolder 가 생성될 때 실행됨, 전체 UI를 생성함
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return MyViewHolder(ItemMainBinding.inflate(LayoutInflater.from(parent.context),
            parent, false))
    }
//    생성된 리사이클러 뷰의 ViewHolder 에 데이터를 연동
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        Log.d("KSC-Recycler","ibBindViewHolder : $position")

        val binding= (holder as MyViewHolder).binding

//        뷰 데이터 출력
        binding.itemData.text = items[position]

//        뷰에 이벤트 추가
        binding.itemData.setOnClickListener {
            Log.d("KSC","item root click : $position")
        }
    }

}