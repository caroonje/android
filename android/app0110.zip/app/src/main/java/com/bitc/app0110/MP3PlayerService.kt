package com.bitc.app0110

import android.app.Service
import android.content.Intent
import android.os.IBinder

class MP3PlayerService : Service() {

    override fun onBind(intent: Intent): IBinder {
        TODO("Return the communication channel to the service.")
    }
}