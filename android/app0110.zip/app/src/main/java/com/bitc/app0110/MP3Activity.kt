package com.bitc.app0110

import android.bluetooth.BluetoothClass.Service
import android.content.ComponentName
import android.content.ServiceConnection
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.IBinder
import com.bitc.app0110.databinding.ActivityMp3Binding

class MP3Activity : AppCompatActivity() {

    var mP3PlayerService: MP3PlayerService? = null

    val mP3PlayerServiceConnection: ServiceConnection = object : ServiceConnection{
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            mP3PlayerService = (service as MP3PlayerService.MP3PlayerBinder).getService()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMp3Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnMp3Play.setOnClickListener {
            mP3PlayerService?.play()
        }

        binding.btnMp3Stop.setOnClickListener {
            mP3PlayerService?.stop()
        }

        binding.btnMp3Pause.setOnClickListener {
            mP3PlayerService?.pause()
        }


    }
}