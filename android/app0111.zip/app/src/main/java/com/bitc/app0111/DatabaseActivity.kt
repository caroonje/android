package com.bitc.app0111

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bitc.app0111.databinding.ActivityDataBaseBinding

class DatabaseActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityDataBaseBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val dbHelper = DBHelper(this)
        val database = dbHelper.writableDatabase

        binding.btnInsert.setOnClickListener {
            dbHelper.dbInsert(database)
        }
        binding.btnUpdate.setOnClickListener {
            dbHelper.dbUpdate(database)
        }
        binding.btnDelete.setOnClickListener {
            dbHelper.dbDelete(database)
        }
        binding.btnSelect.setOnClickListener {
            val text = dbHelper.dbSelect(database)
            binding.tvResult.text = text
        }


    }
}